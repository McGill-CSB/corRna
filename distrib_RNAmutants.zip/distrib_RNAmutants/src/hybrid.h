void init_Mutant_arrays_hybrid();
void update_init_hybrid_param(double value);
void precomputeHairpin_hybrid(int cutoff, int include_intermolecular_interactions);
void RNAmutants_algorithm_hybrid(int verbose);
